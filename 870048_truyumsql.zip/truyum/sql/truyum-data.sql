use truyum;
insert into menu_item(name,
price ,active ,
dateOfLaunch ,
category ,
freeDelivery)
values('sandwich',99.00,'yes','2017-03-15','main course','yes'),
('burger',129.00,'yes','2017-12-23','main course','no'),
('pizza',149.00,'yes','2017-08-21','main course','no'),
('french fries',57.00,'no','2017-07-02','starters','yes'),
('chocolate brownie',32.00,'yes','2022-11-02','desert','yes');
select name,concat('Rs. ',price) as 'price',active,dateOfLaunch,category,freeDelivery from menu_item;

select name,concat('Rs. ',price) as 'price',category,freeDelivery from menu_item where dateOfLaunch<now() and active='yes';

select name,concat('Rs. ',price) as 'price',active,dateOfLaunch,category,freeDelivery from menu_item where menuID=1;

update menu_item
set price='50.00' where menuID=1;

insert into users(username)values('kim'),('tom');
insert into cart(userID,menuID) values(2,1),(2,2),(2,3);
select * from cart;

select name,freeDelivery,concat('Rs. ',price) as 'price',active,dateOfLaunch from menu_item m 
inner join cart c on m.menuID=c.menuID inner join users u on c.userID=u.userID where c.userID=2;

select concat('Rs. ',CAST(sum(price) as CHAR)) as 'Total' from menu_item m inner join
cart c on m.menuID=c.menuID inner join users u on c.userID=u.userID where c.userID=2;

delete from cart where userID=2 and menuID=1;