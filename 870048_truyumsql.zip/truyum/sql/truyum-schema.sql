create database truyum;
use truyum;
create table menu_item(
menuID int auto_increment primary key,name varchar(100),
price decimal(6,2), active varchar(10),
dateOfLaunch date,
category varchar(20),
freeDelivery varchar(10)
);

create table users(userID int auto_increment primary key,username varchar(100));

create table cart(
cartID int auto_increment primary key,userID int,menuID int,
constraint f_userid foreign key(userID) references users(userID),
constraint f_menuid foreign key(menuID) references menu_item(menuID)
);

